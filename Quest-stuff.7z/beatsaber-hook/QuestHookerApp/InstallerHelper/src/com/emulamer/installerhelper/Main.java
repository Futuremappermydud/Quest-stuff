/*
package com.emulamer.installerhelper;

import com.emulamer.installerhelper.*;

import java.io.File;


public class Main
{

    public static void main(String[] args)
    {
        DexHelper dx = new DexHelper();
        try {
            dx.injectDex(new File("C:\\Users\\VR\\Desktop\\platform-tools_r28.0.3-windows\\externalstorage\\classes.dex"), new File("C:\\Users\\VR\\Desktop\\platform-tools_r28.0.3-windows\\externalstorage\\output\\out.dex"));
        } catch (Exception ex)
        {

        }


    }

}
*/
